<?php require_once('../connection.php'); 
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
}
if (isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];
}
echo "$user_id";
?>
<?php
    // Fetch the course details based on the provided course ID
    $id = $_GET['id'];
    $year = $_GET['year'];
    $sem = $_GET['sem'];

    // Check if the form is submitted
    if(isset($_POST['save'])){
        // Escape user inputs for security
        $courseID = mysqli_real_escape_string($connection, $id);
        $courseCode = mysqli_real_escape_string($connection, $_POST['code']);
        $courseName = mysqli_real_escape_string($connection, $_POST['name']);
        $credits = mysqli_real_escape_string($connection, $_POST['credits']);
        $lectureHours = mysqli_real_escape_string($connection, $_POST['hours']);

        // Update the course details in the database
        $query = "UPDATE `course` SET `course_code`='$courseCode', `course_name`='$courseName', `credits`='$credits', `lecture_hours`='$lectureHours', `semester`='$sem', `year`='$year' WHERE `course_id`='$courseID'";
        $result = mysqli_query($connection, $query);

        // Check if the query executed successfully
        if($result){
            // Redirect to course_list.php with year and sem parameters
            header("Location: course_list.php?year=$year&sem=$sem&user_id=$user_id");
            exit(); // Stop further execution
        } else {
            // Display error message if query fails
            echo "Error: " . mysqli_error($connection);
        }
    }

    // Fetch the course details based on the provided course ID
    $query = "SELECT * FROM `course` WHERE `course_id`='$id'";
    $result = mysqli_query($connection, $query);

    // Check if the course exists
    if(mysqli_num_rows($result) > 0){
        $row = mysqli_fetch_assoc($result);
        $courseName = $row['course_name'];
        $courseCode = $row['course_code'];
        $credits = $row['credits'];
        $lectureHours = $row['lecture_hours'];
    } else {
        echo "Course not found.";
        exit(); // Stop further execution
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Course</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        .container{
            width: 300px;
            margin: 20px auto;
            background-color: aliceblue;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        form {
			margin-top: 20px;
			margin-bottom: 20px;
        }
        input[type="text"], select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        input[type="submit"], input[type="button"] {
            background-color: lightblue;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            font-size: 16px;
            font-family: Arial, Helvetica, sans-serif;
            margin-top: 20px;
            cursor: pointer;
            border-radius: 10px;
            display: block;
            margin: auto;
        }
        input[type="submit"]:hover, input[type="button"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">

    <h1>Edit Course</h1>
    <hr>

    <!-- Form to edit the course details -->
    <form action="course_edit.php?id=<?php echo $id; ?>&year=<?php echo $year; ?>&sem=<?php echo $sem; ?>&user_id=<?php echo $user_id;?>" method="post">
        <label for="name">New Course Name:</label>
        <input type="text" id="name" name="name" value="<?php echo $courseName; ?>" required><br>
        <label for="code">New Course Code:</label>
        <input type="text" id="code" name="code" value="<?php echo $courseCode; ?>" required><br>
        <label for="credits">Credits:</label>
        <select id="credits" name="credits" required>
            <option value="3" <?php if($credits == 3) echo "selected"; ?>>3</option>
            <option value="4" <?php if($credits == 4) echo "selected"; ?>>4</option>
        </select><br>
        <label for="hours">Lecture Hours:</label>
        <input type="text" id="hours" name="hours" value="<?php echo $lectureHours; ?>" required><br>
        <input type="submit" name="save" value="Save">
    </form>

    <!-- Cancel button to go back to course_list.php -->
    <form action="course_list.php?year=<?php echo $year; ?>&sem=<?php echo $sem; ?>&user_id=<?php echo $user_id;?>" method="post"> <!-- Pass year and sem back to course_list.php -->
        <input type="submit" name="cancel" value="Cancel">
    </form>
    </div>

</body>
</html>
