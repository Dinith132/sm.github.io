<?php 
    require_once('../connection.php'); 

    if (isset($_GET['user_id'])) {
        $u_id = $_GET['user_id'];
    }
    if (isset($_POST['user_id'])) {
        $u_id = $_POST['user_id'];
    }
    echo "$u_id";
?>


<!DOCTYPE html>
<html>
<head>
    <title>Lecture List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        .container {
            width: 800px;
            margin: 50px auto;
            background-color: aliceblue;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        form {
			margin-top: 20px;
			margin-bottom: 20px;
        }
        select, input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid black;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            border: none;
            color: white;
            font-size: 16px;
            cursor: pointer;
            border-radius: 10px;
        }
        .edit{
            background-color: lightblue;
        }
        .edit:hover{
            background-color: #0056b3;
        }
        .delete{
            background-color: red;
        }
        .delete:hover {
            background-color: maroon;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">

    <?php 

        $query = "SELECT `user_id`, `first_name`, `middle_name`, `last_name`, `email` FROM `user` WHERE `role`='lecture'";
        $record = mysqli_query($connection, $query);

        // Check if the query was successful
        if($record) {
            echo "<h1>Lecturers</h1>";
            echo "<hr>";
            echo "<table border='1'>";
            echo "<tr>
                      <th>Full Name</th>
                      <th>Profession</th>
                      <th>Email</th>
                      <th>Edit</th>
                      <th>Delete</th>
                  </tr>";

            // Loop through the records and display each lecturer in a table row
            while ($row = mysqli_fetch_assoc($record)) {
                $user_id = $row['user_id'];
                $full_name = $row['first_name'] . " " . $row['middle_name'] . " " . $row['last_name'];
                $email = $row['email'];

                // Query to fetch profession from the lecture table based on user_id
                $profession_query = "SELECT `profession` FROM `lecture` WHERE `lecture_id`='$user_id'";
                $profession_result = mysqli_query($connection, $profession_query);

                // Check if the profession query was successful
                if($profession_result && mysqli_num_rows($profession_result) > 0) {
                    $profession_row = mysqli_fetch_assoc($profession_result);
                    $profession = $profession_row['profession'];
                } else {
                    $profession = "Unknown"; // Default value if profession is not found
                }

                // Displaying data in table row
                echo "<tr>
                          <td>$full_name</td>
                          <td>$profession</td>
                          <td>$email</td>
                          <td>
                              <form action='lecture_edit.php?&u_id=$u_id' method='post'> 
                                  <input type='hidden' name='user_id' value='$user_id'>
                                  <input class='edit' type='submit' name='edit' value='Edit'>
                              </form>
                          </td>
                          <td>
                              <form action='lecture_delete.php?&u_id=$u_id' method='post'> 
                                  <input type='hidden' name='user_id' value='$user_id'>
                                  <input class='delete' type='submit' name='delete' value='Delete'>
                              </form>
                          </td>
                      </tr>";
            }

            echo "</table>";
        } else {
            echo "Error in database";
        }
    ?>
    <form class="container" action="lecture_add.php?&user_id=<?php echo $u_id;?>" method="post">
      <input type="submit" name="add" value="Add">
    </form>
    <button id="back">back</button>
    </div>

    <script>
        document.getElementById("back").onclick = function() {
            window.location.href = "MA.php?&user_id=<?php echo $u_id;?>";
        };
    </script>
    
</body>
</html>
