<?php require_once('../connection.php');
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
}
if (isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];
}
echo "$user_id";
?>

<!DOCTYPE html>
<html>

<head>
    <title></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: lightblue;
        }

        .container {
            width: 800px;
            margin: 50px auto;
            background-color: aliceblue;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-left: 30%;
        }

        form {
            margin-top: 20px;
            margin-bottom: 20px;
            margin-left: 40px;
            text-align: left;
        }

        select {
            width: auto;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        select:focus {
            outline: none;
        }

        input[type="submit"] {
            background-color: lightblue;
            border: none;
            color: white;
            padding: 15px 32px;
            /* text-align: center; */
            font-size: 16px;
            font-family: Arial, Helvetica, sans-serif;
            margin-top: 20px;
            cursor: pointer;
            border-radius: 10px;
            display: block;
            margin: auto;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        #form_1 {
            /* width: 95%; */
            float: right;
            font-size: 100%;
        }
    </style>
</head>

<body>
    <div class="container">
        <?php

        // Query to fetch distinct years
        $year_query = "SELECT DISTINCT `year` FROM `course`";
        $year_result = mysqli_query($connection, $year_query);

        // Array to store available years
        $available_years = array();

        // Fetching available years and populating the array
        while ($row = mysqli_fetch_assoc($year_result)) {
            $available_years[] = $row['year'];
        }

        // Check if semester and year are received via $_GET
        if (isset($_GET['year']) && isset($_GET['sem'])) {
            $year = $_GET['year'];
            $sem = $_GET['sem'];
        } else {
            // If not received, use form inputs
            if (isset($_POST['ok'])) {
                $year = $_POST['year'];
                $sem = $_POST['sem'];
            }
        }

        // Fetch courses based on year and semester
        if (isset($year) && isset($sem)) {
            $query = "SELECT `course_id`,`course_name`,`course_code`,`credits`,`lecture_hours` FROM `course` WHERE `year`='$year' AND `semester`='$sem'";
            $record = mysqli_query($connection, $query);

            if ($record) {
                $table = '<table>';
                $table .= '<caption>Semester: ' . $sem . '|  Year: ' . $year . '</caption>' . '<hr>';
                $table .= '<tr><th>Name</th> <th>Code</th> <th>Credits</th> <th>Lecture Hours</th> <th>Action</th></tr>';
                while ($result = mysqli_fetch_assoc($record)) {
                    $table .= "<tr>";
                    $table .= '<td>' . $result['course_name'] . '</td>';
                    $table .= '<td>' . $result['course_code'] . '</td>';
                    $table .= '<td>' . $result['credits'] . '</td>';
                    $table .= '<td>' . $result['lecture_hours'] . '</td>';
                    $table .= '<td><a href="course_edit.php?id=' . $result['course_id'] . '&year=' . $year . '&sem=' . $sem . '&user_id=' . $user_id . '">Edit</a> | <a href="course_delete.php?id=' . $result['course_id'] . '&year=' . $year . '&sem=' . $sem . '&user_id=' . $user_id . '">Delete</a></td>';
                    $table .= "</tr>";
                }
                $table .= '</table>';
            }
        }
        ?>

        <h1>Course List</h1>
        <hr>

        <!-- Form to select year and semester -->
        <form action="course_list.php?user_id=<?php echo $user_id; ?>" method="post">

            <!-- Dynamic generation of year options -->
            year-<select name="year" required>
                <?php foreach ($available_years as $year) { ?>
                    <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                <?php } ?>
            </select>

            semester-<select name="sem" required>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
            </select>
            <input style="margin-top: 10px;" type="submit" name="ok" value="OK">

        </form>

        <!-- Display the table if records are fetched -->
        <?php if (isset($table)) {
            echo $table;
        } ?>

        <!-- Add button to add a new course -->
        <form action="course_add.php?&user_id=<?php echo $user_id; ?>" method="post">
            <input type="submit" name="add" value="Add">
        </form>

        <form action="MA.php?&user_id=<?php echo $user_id; ?>" method="post">

            <input type="submit" name="back" value="back">
        </form>
    </div>
</body>

</html>