<?php require_once('../connection.php');
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
}
if (isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];
}
echo "$user_id"; ?>
<?php

$passwordMismatch = false; // Flag to track password mismatch
if (isset($_GET['user_id'])) {
  $user_id = $_GET['user_id'];
}
if (isset($_POST['user_id'])) {
  $user_id = $_POST['user_id'];
}

if (isset($_POST['change'])) {
  $password = mysqli_real_escape_string($connection, $_POST['pw']);
  $confirmPassword = mysqli_real_escape_string($connection, $_POST['pw2']);

  // Check if passwords match
  if ($password !== $confirmPassword) {
    $passwordMismatch = true;
  } else {

    // Build the SQL query with proper quoting
    $query = "UPDATE `user` SET `password`='$password' WHERE `user_id`='$user_id';";

    $result = mysqli_query($connection, $query);

    if ($result) {
      echo "Password changing is sucssesfull.";
    } else {
      echo "Error";
    }
  }
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>Reset Password</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: lightblue;
      font-size: 110%;

    }

    .container {
      width: 800px;
      margin: 50px auto;
      background-color: aliceblue;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
      /* text-align: left; */
      margin-left: 30%;

    }

    #batch_no {
      margin-left: 40px;

    }

    form {
      margin-top: 20px;
      margin-bottom: 20px;
      margin-left: 40px;
      text-align: left;
    }

    select,
    input[type="submit"] {
      width: auto;
      padding: 10px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }

    table {
      width: 90%;
      border-collapse: collapse;
      align-items: center;
      margin-left: 40px;
      font-size: 100%;
    }

    th,
    td {
      border: 1px solid #ddd;
      padding: 8px;
      text-align: left;
      width: 150px;
    }

    th {
      background-color: #f2f2f2;
    }

    #back {
      margin-left: 40px;
      margin-bottom: 40px;
      size: 100%;
      width: 100px;
      height: 40px;
      font-size: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;

    }

    form {
      width: 400px;
      margin: 50px auto;
      background-color: aliceblue;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      text-align: left;
    }

    input[type="text"],
    input[type="submit"] {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }

    input[type="submit"] {
      background-color: lightblue;
      border: none;
      color: white;
      font-size: 16px;
      cursor: pointer;
      margin-top: 20px;
      border-radius: 5px;
    }

    input[type="submit"]:hover {
      background-color: #0056b3;
    }

    #form_1 {
      /* width: 95%; */
      float: right;
      font-size: 100%;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Reset Password</h1>
    <hr>
    <form action="reset.php" method="post">
      Password <input type="password" name="pw" required><br>
      Confirm password <input type="password" name="pw2" required><br>
      <?php
      if ($passwordMismatch) {
        echo "Passwords do not match. Please try again.";
      }
      ?><br>
      <br>
      <input type="hidden" name="user_id" value='<?php echo "$user_id"?>'>
      <input type="submit" name="change" value="change">
      <input type="hidden" name="user_id" value=<?php echo "$user_id"; ?>>
    </form>
    <form action="MA.php" method="post">
        <input type="hidden" name="user_id" value=<?php echo "$user_id"; ?>>
        <input type="submit" name="back" value="Back">
    </form>
    
  </div>




</body>

</html>